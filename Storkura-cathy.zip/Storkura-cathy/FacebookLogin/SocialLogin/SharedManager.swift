//
//  SharedManager.swift
//  SocialLogin
//
//  Created by Cathy Chi on 3/15/17.
//  Copyright © 2017 Cathy Chi. All rights reserved.
//

import Foundation

class SharedManager {
    var user = User()
    static let sharedInstance = SharedManager()
}
